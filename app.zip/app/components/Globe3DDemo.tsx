"use client";

import { Globe3D, GlobeMarker } from "@/components/ui/3d-globe";
import { useTheme } from "next-themes";
import { useEffect, useState } from "react";

const sampleMarkers: GlobeMarker[] = [
  {
    lat: 19.1197,
    lng: 72.8468,
    // src: "/SeedVest_Logo.svg",
    src: "/White_Logo.svg",
    label: "Andheri",
  },
];

export function Globe3DDemo({
  globeSpeed,
  onGlobeLoaded,
}: {
  globeSpeed: number;
  onGlobeLoaded: () => void;
}) {
  const { resolvedTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  useEffect(() => setMounted(true), []);
  if (!mounted) return null;

  const isDark = resolvedTheme === "dark";

  return (
    <div
      className="w-full h-full"
      style={
        !isDark
          ? {
              filter: "contrast(0.9) brightness(1.6)",
            }
          : undefined
      }
    >
      <Globe3D
        key={resolvedTheme}
        markers={sampleMarkers}
        onLoaded={onGlobeLoaded}
        config={{
          bumpScale: 100,
          autoRotateSpeed: globeSpeed,
        }}
      />
    </div>
  );
}
